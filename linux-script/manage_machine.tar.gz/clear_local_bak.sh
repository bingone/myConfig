##!/bin/sh

# local db bak data clear
/usr/local/bin/pssh -h /home/admin/host/all_shard -t 600 -p 37 -i find /data/db.bak -mtime +7 -delete >> /data/log/clear.log 2>&1
