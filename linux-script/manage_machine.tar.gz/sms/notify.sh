#/bin/sh
PWD=$(cd "$(dirname $0)";pwd)
log="$PWD/record.log"
apikey="c252fc21b8243b969c102de00e01073e"
for phone in `cat "$PWD/contact.list"`;do
  date "+%Y-%m-%d %H:%M:%S" >> $log
  curl --data "apikey=$apikey&mobile=$phone&code=168168" "http://voice.yunpian.com/v1/voice/send.json" >> $log
done
