log=/tmp/netstat.log
while [ 1 == 1 ]
do
  echo `date +%D\ %T` >> $log
  netstat -n | awk '/^tcp/ {++S[$NF]} END {for(a in S) print a, S[a]}' >> $log
  sleep 1
done
