echo never > /sys/kernel/mm/transparent_hugepage/enabled
echo never > /sys/kernel/mm/transparent_hugepage/defrag
sed -i 's/4096/65535/' /etc/security/limits.d/20-nproc.conf
