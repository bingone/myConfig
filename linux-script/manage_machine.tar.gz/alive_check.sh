#!/bin/sh
PWD=$(cd "$(dirname $0)";pwd)
CONFIG=$1
MY_NAME=`basename ${CONFIG} .sh`
LOCK="$PWD/$MY_NAME.lock"
if [ -f $LOCK ];then
   echo "last check not finished lock:$LOCK"
   exit 2
fi
touch $LOCK
dt=`date +%Y-%m-%d\ %T`
for i in `cat ${CONFIG}`;
do
  arr=(${i//,/ })
  ip=${arr[0]}
  process=${arr[1]}
  ret=`ssh -o ConnectTimeout=3 ${ip} "ps aux|grep '${process}'|grep 'grep' -v"`
  if [ $? -ne 0 ];then
     echo "${dt} process [${process}]@${ip} not found, it may crashed, pls check!"
     /usr/local/bin/python /home/admin/w/src/tool/mail/mail.py "${dt} process [${process}]@${ip} not found, it may crashed, pls check" "dev@taovip.com" "${MY_NAME} Process Crash Check"
     echo "send email return $?"
  else
     echo "${dt} process [${process}]@${ip} check ok!"
  fi
done
rm $LOCK
