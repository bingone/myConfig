#!/bin/bash

if [ "$1x" = "-hx" -o $# -lt 4 ];
then
   echo "Usage 1: $0 hostfile user password user_to_change user_password"
   exit 2
fi

auto_smart_ssh () {
    expect -c "set timeout -1;
                spawn ssh -o StrictHostKeyChecking=no $2 ${@:3};
                expect {
                    *assword:* {send -- $1\r;
                                 expect { 
                                    *denied* {exit 2;}
                                    eof
                                 }
                    }
                    eof         {exit 1;}
                }
                " 
    return $?
}

hostfile=$1
user=$2
password=$3
user_to_change=$4
user_password=$5

for host in `cat $hostfile`
do
  echo $host
  auto_smart_ssh $password $user@$host "echo '$user_password${host:3}' | passwd --stdin $user_to_change"
  echo -e "--$host Exit Status: $?"
  echo
done
