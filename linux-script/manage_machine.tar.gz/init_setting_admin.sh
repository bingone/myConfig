#init setting for admin

mkdir -p /home/admin/.ssh
chmod 700 /home/admin/.ssh
cat /tmp/id_rsa.pub.admin >> /home/admin/.ssh/authorized_keys
chmod 600 /home/admin/.ssh/authorized_keys
mkdir -p /data/log
#mkdir -p /data/mongodb
#mkdir -p /data/mongodb-config
