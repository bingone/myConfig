ssh -i california-yp-rest-1.pem ec2-user@52.8.161.153
