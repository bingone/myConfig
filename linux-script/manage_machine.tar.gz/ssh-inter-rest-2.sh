ssh -i california-rest-2.pem ec2-user@54.67.46.52
