#!/bin/sh

log_path=`cat /home/admin/box/log_path`
all_path=""
for p in $log_path;
do
  if [ "$all_path" == "" ];then
    all_path="$p"
  else
    all_path="$all_path $p"
  fi
done
/usr/local/bin/pssh -h /home/admin/host/newall -p 90 "find $all_path -type f -mtime +45 -delete > /dev/null 2>&1 &" >> /data/log/clear.log 2>&1

