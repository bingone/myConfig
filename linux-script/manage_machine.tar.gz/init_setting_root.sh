#init setting for root

mkdir -p /root/.ssh
chmod 700 /root/.ssh
cat /tmp/id_rsa.pub.root >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys

adduser admin
echo 'adminpwd' | passwd --stdin admin
