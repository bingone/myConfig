mkdir -p /data/log
mkdir -p /data/mongodb
mkdir -p /data/mongodb-config
