#!/bin/sh

if [ $# -lt 2 ];then
   echo "$0 xM file"
   echo "xM is the size truncated per time, in MB"
   exit 2
fi

m=$1
shift 
filelist=`ls $@`
echo "target file list:\n${filelist}"
for f in $filelist;
do 
  s=`du -sm $f | awk '{print $1}'`
  echo "truncate and rm ${f}, total file size:${s}M"
  for i in `seq $s -$m 1`;
  do
    truncate -s ${i}M $f
    ls -lh $f
    sleep 1
  done
  rm $f
done
