#!/bin/sh

# remote bak data clear
/usr/local/bin/pssh -h /home/admin/host/xy find /data/db.bak -mtime +10 -delete >> /data/log/clear.log 2>&1
