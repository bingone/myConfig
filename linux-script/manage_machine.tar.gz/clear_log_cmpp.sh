#!/bin/sh

log_path=`cat /home/admin/box/log_path_cmpp_3day`
all_path=""
for p in $log_path;
do
  if [ "$all_path" == "" ];then
    all_path="$p"
  else
    all_path="$all_path $p"
  fi
done
echo $all_path
/usr/local/bin/pssh -h /home/admin/host/cmpp/hostlist -p 5 "find $all_path -type f -mtime +3 -delete > /dev/null 2>&1 &" >> /data/log/clear_cmpp.log 2>&1

