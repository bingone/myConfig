ssh -i awskeypair-california.pem ec2-user@52.8.121.40
