#!/bin/bash

if [ "$1x" = "-hx" -o $# -lt 4 ];
then
   echo "Usage 1: $0 user password hostfile command"
   echo "Usage 2: $0 user password hostfile \"command 1;command 2\""
   exit 2
fi

auto_smart_ssh () {
    expect -c "set timeout -1;
                spawn ssh -o StrictHostKeyChecking=no $2 ${@:3};
                expect {
                    *assword:* {send -- $1\r;
                                 expect { 
                                    *denied* {exit 2;}
                                    eof
                                 }
                    }
                    eof         {exit 1;}
                }
                " 
    return $?
}

user=$1
password=$2
hostfile=$3
shift
shift
shift
command=$@

for host in `cat $hostfile`
do
  echo $host
  auto_smart_ssh $password $user@$host "$command"
  echo -e "--$host Exit Status: $?"
  echo
done
