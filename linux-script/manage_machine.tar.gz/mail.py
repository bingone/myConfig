#!/usr/local/bin/python
#-*- coding:utf-8 -*-
# Author: jq
# Time: 2013-05-18 11:48
# Desc: 

import smtplib
import sys

DEFAULT_TO_ADDRESS = ['jacky@taovip.com','sumekey@taovip.com','jiacheo@taovip.com','zhoujian@taovip.com']
DEFAULT_FROM_ADDRESS = 'system@taovip.com'
DEFAULT_SUBJECT = 'rabbitmq监控警告'
USER_NAME = 'system@taovip.com'
PASSWORD = 'sys123'
#DEFAULT_FROM_ADDRESS = 'wkmonitor@qq.com'
#DEFAULT_SUBJECT = '监控警告'
#USER_NAME = 'wkmonitor'
#PASSWORD = 'weike123'

#DEFAULT_FROM_ADDRESS = 'nb.com.cn@gmail.com'
#DEFAULT_SUBJECT = '监控警告'
#USER_NAME = 'nb.com.cn'
#PASSWORD = 'newzidane'

def sendMailOnce(text, toAddr=DEFAULT_TO_ADDRESS, subject=DEFAULT_SUBJECT):
    """
    一次性使用的发送接口,每次都新建连接,发送完成发自动关闭
    """
    ms = MailSender()
    ms.sendMail(text, toAddr, subject)
    ms.close()

class MailSender:
    def __init__(self):
#        self.server = smtplib.SMTP('smtp.gmail.com', port=587)
#        self.server.starttls()
        self.server = smtplib.SMTP('smtp.qq.com', port=25)
        self.server.login(USER_NAME, PASSWORD)

    def sendMail(self, text, toAddr=DEFAULT_TO_ADDRESS, subject=DEFAULT_SUBJECT):
        msg = 'Subject: %s\n\n%s' % (subject, text)
        try:
            self.server.sendmail(DEFAULT_FROM_ADDRESS, toAddr, msg)
        except Exception, e:
            print('EXCEPTION:%s'%str(e))

    def close(self):
        self.server.quit()

if __name__ == '__main__':
    if len(sys.argv) == 4:
        toAddr = sys.argv[1].split(',')
        subject = sys.argv[2]
        text = sys.argv[3]
        sendMailOnce(text, toAddr, subject)
    elif len(sys.argv) == 2:
        text = sys.argv[1]
        sendMailOnce(text)
    else:
        print('usage:%s <toAddr>(comma seperated) <subject> text'%sys.argv[0])
        sys.exit(2)

