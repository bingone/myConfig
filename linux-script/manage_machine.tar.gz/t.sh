file="host_process_list"
for i in `cat ${file}`;
do
  echo ${i}
  arr=(${i//,/ })
  echo ${arr[0]}
  echo ${arr[1]}
done
